#include <stdio.h>
#include "decode.h"
#include "types.h"
#include<string.h>
//read and validating the arguements
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    int i=0;
    for(i=0;argv[i]!=0;i++);
    //checking the proper number of arguement
    if(i<3)
    {
	printf("Invalid number of arguments\nTry passing 4<=count of arguments>=5 arguments\n");
	return e_failure;
    }
    //substring .bmp file present or not
    if(!(strstr(argv[2],".bmp")))
    {
	printf("Invalid file\nPlease provide the file with extension .bmp\n");
	return e_failure;
    }
    //4th arguent is null adding output to it later it is concatinated with .txt file
    if(argv[3]==NULL)
    {
	strcpy(decInfo->output_fname,"output");
    }
    if(argv[3]!=NULL)
    {
	strcpy(decInfo->output_fname,argv[4]);
    }
    strcpy(decInfo->stego_image_fname,argv[2]);
    printf("READ AND VALIDIDATED SUCCESSFULLY FOR DECODING\n");
    do_decoding(decInfo);
}
Status opende_files(DecodeInfo *decInfo)
{
    // Src Image file
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_stego_image == NULL)
    {
    
    	printf("error while opening file");

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
//decoding part to access data
Status do_decoding(DecodeInfo *decInfo)
{
    //file open to read
    if(opende_files(decInfo))
    {
	printf("ERROR FOUND");
	return 0;
    }
    else
    {
        printf("OPENING OF FILE FOR DECODING SUCCESSFULL\n");
    }
    //skip header to read actual value
   if(skip_bmp_header(decInfo->fptr_stego_image))
   {
       printf("ERROR FOUND");
       return 0;
   }
   if(decode_magic_stringlen(decInfo))
   {
       printf("ERROR FOUND");
       return 0;
   }
  if(decode_magic_string(decInfo->magic_string,decInfo))
  {
      printf("ERROR FOUND");
      return 0;
  }
  char strm[100];
  printf("ENTER MAGIC STRING FOR DECODING : ");
  scanf("%[^\n]",strm);
  //comparing magic string with accessed data 
  if(strcmp(strm,decInfo->magic_string))
  {
      printf("ENTER VALID STRING FOR DECODE");
      return 0;
  }
  if(decode_secret_ext_len(decInfo))
  {
      printf("ERROR FOUND");
      return 0;
  }
  char file_extn[100];
   if(decode_secret_file_extn(file_extn,decInfo))
   {
       printf("ERROR FOUND");
       return 0;
   }
   //concatinating output file with .txt file
   strcat(decInfo->output_fname,file_extn);
    decInfo->fptr_output_file = fopen(decInfo->output_fname, "w");
    // Error handling
    if (decInfo->fptr_output_file == NULL)
    {
    	printf("Unable to open file");

    	return e_failure;
    }
   if(decode_secret_file_size(decInfo))
   {
       printf("ERROR FOUND");
       return 0;
   }
  if(decode_secret_file_data(decInfo))
  {
      printf("ERROR FOUND");
      return 0;
  }
  
   
}
Status skip_bmp_header(FILE *fptr_stego_image)
{
    fseek(fptr_stego_image,54,SEEK_SET);
    return e_success;
}
Status decode_magic_stringlen(DecodeInfo *decInfo)
{
    char magic_len[32];
    fread(magic_len,32,1,decInfo->fptr_stego_image);
    decode_byte_to_int(&decInfo->magic_string_len,magic_len);
    return e_success;
}
Status decode_byte_to_int(int *data, char *image_buffer)
{
    int mask;
    *data=0;
    for(int i=0;i<32;i++)
    {
     mask=image_buffer[i]&1;
     *data=*data+(mask*((1<<(31-i))));
    }
}
Status decode_byte_to_lsb(char *data, char *image_buffer)
{
    char mask;
    int sum=0;

    for(int i=0;i<8;i++)
    {
         //loop to access bits from lsb 
     mask=image_buffer[i]&1;
     sum=sum+(mask*((1<<(7-i))));
    }
    *data=(char)sum;
}
Status decode_magic_string(char *magic_string,DecodeInfo *decInfo)
{
    int j=decInfo->magic_string_len;
    char buffer[8];
    char ch;
    int i=0;
   //loop to read from stego file
    for(i=0;i<j;i++)
    {
    fread(buffer,8,1,decInfo->fptr_stego_image);
    decode_byte_to_lsb(&ch,buffer);
    magic_string[i]=ch;
    }
    magic_string[i]=0;
    return e_success;
}
Status decode_secret_ext_len(DecodeInfo *decInfo)
{
    char file_ext_len[32];
    fread(file_ext_len,32,1,decInfo->fptr_stego_image);
    decode_byte_to_int(&decInfo->file_exten_size,file_ext_len);
    return e_success;
}
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo)
{
    int j=8*decInfo->file_exten_size;
    char buffer[8];
    char ch;
    int i=0;
    for(i=0;i<j;i++)
    {
    fread(buffer,8,1,decInfo->fptr_stego_image);
    decode_byte_to_lsb(&ch,buffer);
    //accesing character stored in string
    file_extn[i]=ch;
    }
    file_extn[i]=0;
    return e_success;
}
Status decode_secret_file_size(DecodeInfo *decInfo)
{
    char file_data_len[32];
    fseek(decInfo->fptr_stego_image,166,SEEK_SET);
    fread(file_data_len,32,1,decInfo->fptr_stego_image);
    decode_byte_to_int(&decInfo->sec_file_size,file_data_len);
    return e_success;
}
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    int j=decInfo->sec_file_size;
   fseek(decInfo->fptr_stego_image,198,SEEK_SET);
    char buffer[8];
    char ch;
    int i=0;
    for(i=0;i<j;i++)
    {
        //reading from file
    fread(buffer,8,1,decInfo->fptr_stego_image);
    decode_byte_to_lsb(&ch,buffer);
    //secret code to output file
    putc(ch,decInfo->fptr_output_file);
    }
    return e_success;
}
