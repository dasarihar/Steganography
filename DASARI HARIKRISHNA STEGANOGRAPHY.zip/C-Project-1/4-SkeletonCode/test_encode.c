#include <stdio.h>
#include "encode.h"
#include "types.h"
#include "decode.h"

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    int i=0;
    for(i=0;argv[i]!=0;i++);
    //checking proper no of arguements
    if(i<4)
    {
	printf("Invalid number of arguments\nTry passing 4<=count of arguments>=5 arguments\n");
	return e_failure;
    }
    if(!(strstr(argv[2],".bmp")))
    {
	printf("Invalid file\nPlease provide the file with extension .bmp\n");
	return e_failure;
    }
    if(!(strstr(argv[3],".txt")))
    {
	printf("Error:Invalid file\nPlese pass file with extection .txt\n");
	return e_failure;
    }
    //if 5th arguement is null adding arguement to it
    if(argv[4]==NULL)
    {

	strcpy(encInfo->stego_image_fname,"stego_image.bmp");
    }
    //if 5th arguement is  not null adding arguement which is passed
    if(argv[4]!=NULL)
    {
    if(strstr(argv[4],".bmp"))
    {
	strcpy(encInfo->stego_image_fname,argv[4]);
    }
    else
    {
	printf("Error:Invalid file\nProvide File with extension .bmp\n");
	return e_failure;
    }
    }
    strcpy(encInfo->src_image_fname,argv[2]);
    strcpy(encInfo->secret_fname,argv[3]);
    printf("SUCCESFULLY READ AND VALIDATED FOR ENCODING ARGS\n");
}

int main(int argc,char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;
    uint img_size;
    
    
    
    if(check_operation_type(argv) == e_encode)
    {
        //if encode arguement present it goes for validation
       read_and_validate_encode_args(argv,&encInfo);
       //calling decode if all are valid
       do_encoding(&encInfo);
    }
    if(check_operation_type(argv)== e_decode)
    {
       read_and_validate_decode_args(argv,&decInfo);
    }
    if(check_operation_type(argv)== e_unsupported)
    {
	printf("Invalid argument argument should be -e or -d\n");
	return e_failure;

    }
     
}

OperationType check_operation_type(char *argv[])
{
    //comparing arguent for decoding or encoding
    if((strcmp(argv[1],"-e"))==0)
    {
	return e_encode;
    }
    else if((strcmp(argv[1],"-d"))==0)
    {
	return e_decode;
    }
    else
    {
	return e_unsupported;
    }
}
