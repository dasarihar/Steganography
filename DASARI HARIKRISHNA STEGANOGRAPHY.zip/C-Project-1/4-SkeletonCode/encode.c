#include <stdio.h>
#include "encode.h"
#include "types.h"
#include<string.h>

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

    	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

    	return e_failure;
    }

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname,"w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

    	return e_failure;
    }

    // No failure return e_success
    return e_success;
}
  
Status do_encoding(EncodeInfo *encInfo)
{
    //calling all function for encoding
     if(open_files(encInfo))
     {
	 printf("ERROR FOUND");
	 return 0;
     }
     else
     {
        printf("OPENING OF FILE IS SUCCESSFULL\n");
     }
     printf("ENTER MAGIC STRING FOR ENCODING\n");
     scanf("%s",encInfo->magic_string);
     if(check_capacity(encInfo))
     {
	 printf("ERROR FOUND");
	 return 0;
     }
     else
     {
         printf("CAPACITY CHECKING IS SUCCESSFULL\n");
     }
     if(copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image))
     {
	 printf("ERROR FOUND");
	 return 0;
     }
     int length_magic=strlen(encInfo->magic_string);

     if(encode_magic_stringlen(length_magic,encInfo))
     {
	 printf("ERROR FOUND");
	 return 0;
     }
    if(encode_magic_string(encInfo->magic_string,encInfo))
    {
	printf("ERROR FOUND");
	return 0;
    }
    char *ext=strchr(encInfo->secret_fname,'.');
   
    int len_ext=strlen(ext);
   
   if(encode_secret_ext(len_ext,encInfo))
   {
       printf("ERROR FOUND");
       return 0;
   }
   if(encode_secret_file_extn(ext,encInfo))
   {
       printf("ERROR FOUND");
       return 0;
   }
   if(encode_secret_file_size(encInfo->size_secret_file,encInfo))
   {
       printf("ERROR FOUND");
       return 0;
   }
  
    if(encode_secret_file_data(encInfo))
    {
	printf("ERROR FOUND");
	return 0;
    }
   if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_stego_image))
   {
       printf("ERROR FOUND");
   }
   else
   {
    printf("encoded successfully\n");
   }
}
Status check_capacity(EncodeInfo *encInfo)
{
    //source file size
    int src_len=get_image_size_for_bmp(encInfo->fptr_src_image);
    int len_magic=strlen(encInfo->magic_string);
    //.txt as secret extension
    char *str=strchr(encInfo->secret_fname,'.');
    //length of secret file extension
    int len_sec=strlen(str);
   
    char ch;
    //loop to get size of secret file
    while((ch=getc(encInfo->fptr_secret))!=EOF)
    {
	ftell(encInfo->fptr_secret);
    }
    encInfo->size_secret_file =ftell(encInfo->fptr_secret);
    rewind(encInfo->fptr_secret);
    rewind(encInfo->fptr_src_image);
    //total length that we want to store in other file
    int final_len=(4+4+4+len_magic+len_sec+encInfo->size_secret_file)*8+54;
    if(final_len<=src_len)
    {
	return e_success;
    }
}
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char header[54];
    //copying header 
    fread(header,54,1,fptr_src_image);
    fwrite(header,54,1,fptr_dest_image);
    return e_success;
}
Status encode_intbyte_to_lsb(int data, char *image_buffer)
{
    int j=0;
    for(int i=31;i>=0;i--)
    {
        //storing data to lsb of the source file
	unsigned int mask=(data&(1<<i))>>i;
	image_buffer[j]=image_buffer[j]&0xFE;
	image_buffer[j]=image_buffer[j]|mask;
	j++;
    }
}
Status encode_magic_stringlen(int len, EncodeInfo *encInfo)
{
   char magic[32];
   fread(magic,32,1,encInfo->fptr_src_image);
   encode_intbyte_to_lsb(len,magic);
   //write to stego file after changing the lsb bit
   fwrite(magic,32,1,encInfo->fptr_stego_image);
   return e_success;
}
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    int j=0;
    for(int i=7;i>=0;i--)
    {
     //write to stego file after changing the lsb bit
	unsigned int mask =data&(1<<i);
	mask=mask>>i;
	image_buffer[j]=(image_buffer[j]&0xFE);
	image_buffer[j]=image_buffer[j]|mask;
	j++;
    }
}
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    int len=strlen(magic_string);
    char string[8];
    for(int i=0;i<len;i++)
    {
      fread(string,8,1,encInfo->fptr_src_image);
      encode_byte_to_lsb(magic_string[i],string);
      //write to stego file after changing the lsb bit
      fwrite(string,8,1,encInfo->fptr_stego_image);
    }
    return e_success;
} 
Status encode_secret_ext(int len, EncodeInfo *encInfo)
{   
    //reading and storing in lsb bit and again pass to stego file
   char secret_ext[32];
   fread(secret_ext,32,1,encInfo->fptr_src_image);
   encode_intbyte_to_lsb(len,secret_ext);
   fwrite(secret_ext,32,1,encInfo->fptr_stego_image);
   return e_success;
}
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
        //reading and storing in lsb bit and again pass to stego file
    int len=strlen(file_extn);
    char string[8];
    for(int i=0;i<len;i++)
    {
      fread(string,8,1,encInfo->fptr_src_image);
      encode_byte_to_lsb(file_extn[i],string);
      fwrite(string,8,1,encInfo->fptr_stego_image);
    }
    return e_success;
}
Status encode_secret_file_size(int file_size,EncodeInfo *encInfo)
{
       //reading and storing in lsb bit and again pass to stego file
   char file_secret[32];
   fread(file_secret,32,1,encInfo->fptr_src_image);
   encode_intbyte_to_lsb(file_size,file_secret);
   fwrite(file_secret,32,1,encInfo->fptr_stego_image);
   return e_success;
}
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    //reading and storing in lsb bit and again pass to stego file data
    char ch;
    char image_buffer[8];
    rewind(encInfo->fptr_secret);
    while((ch=getc(encInfo->fptr_secret))!=EOF)
    {
	fread(image_buffer,8,1,encInfo->fptr_src_image);
	encode_byte_to_lsb(ch,image_buffer);
	fwrite(image_buffer,8,1,encInfo->fptr_stego_image);
    }
    return e_success;
}
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    //copying remaining data to stego file
    while(!feof(fptr_src))
    {
	ch=getc(fptr_src);
	putc(ch,fptr_dest);
    }
    return e_success;
}
