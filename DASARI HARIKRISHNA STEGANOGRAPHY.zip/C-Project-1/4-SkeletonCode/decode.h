//#ifndef DECODE_H
#define DECODE_H


#include "types.h" // Contains user defined types

typedef struct _DecodeInfo
{
    /* image file containing secrete code*/
    char stego_image_fname[100];
    FILE *fptr_stego_image;
    int magic_string_len;
    int file_exten_size;
    int data;
   char magic_string[100];
    int sec_file_size;

    /* Output File Info */
    char output_fname[100];
    FILE *fptr_output_file;

} DecodeInfo;
/* Check operation type */
OperationType check_operation_type(char *argv[]);

/* Read and validate Encode args from argv */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/* To Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Get File pointers for i/p and o/p files */
Status opende_files(DecodeInfo *decInfo);

/* Skip bmp image header */
Status skip_bmp_header(FILE *fptr_stego_image);

/* Read magic string length */
Status decode_magic_stringlen(DecodeInfo *decInfo);

/* Store Magic String */
Status decode_magic_string(char *magic_string,DecodeInfo *decInfo);

/* Encode secret file extenstion length */
Status decode_secret_ext_len(DecodeInfo *decInfo);

/* Encode secret file extenstioN */
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo);

/* Encode secret file size */
Status decode_secret_file_size(DecodeInfo *decInfo);

/* Encode secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo);

/*decoding  byte from lsb */
Status decode_byte_to_lsb(char *data, char *image_buffer);

/*decoding int from lsb */
Status decode_byte_to_int(int *data, char *image_buffer);
