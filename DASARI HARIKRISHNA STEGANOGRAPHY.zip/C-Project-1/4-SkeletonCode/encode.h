#ifndef ENCODE_H
#define ENCODE_H

#include "types.h" // Contains user defined types

/* 
 * Structure to store information required for
 * encoding secret file to source Image
 * Info about output and intermediate data is
 * also stored
 */

#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4
#include<string.h>
typedef struct _EncodeInfo
{
    /* Source Image info */
    char src_image_fname[100];
    FILE *fptr_src_image;
    uint image_capacity;
    char magic_string[100];
    int magic_len;
    uint bits_per_pixel;
    char image_data[MAX_IMAGE_BUF_SIZE];

    /* Secret File Info */
    char secret_fname[100];
    FILE *fptr_secret;
    char extn_secret_file[MAX_FILE_SUFFIX];
    char secret_data[MAX_SECRET_BUF_SIZE];
    int size_secret_file;

    /* Stego Image Info */
    char stego_image_fname[100];
    FILE *fptr_stego_image;

} EncodeInfo;




/* Check operation type */
OperationType check_operation_type(char *argv[]);
   
/* To encode */
Status do_encoding(EncodeInfo *encInfo);

/* opening of file to use */
Status open_files(EncodeInfo *encInfo);

/* check capacity */
Status check_capacity(EncodeInfo *encInfo);

/* Get image size */
uint get_image_size_for_bmp(FILE *fptr_image);

/* Get file size */
uint get_file_size(FILE *fptr);

/* Copy bmp image header */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image);

/* Store Magic String length */
Status encode_magic_stringlen(int len, EncodeInfo *encInfo);
//to change lsb bit
Status encode_intbyte_to_lsb(int data, char *image_buffer);
//to encode magic string
Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo);
/* Encode a byte into LSB of image data array */
Status encode_byte_to_lsb(char data, char *image_buffer);

/* Encode secret file extenstion */
Status encode_secret_ext(int leng, EncodeInfo *encInfo);

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo);

/* Encode secret file size */
Status encode_secret_file_size(int file_size, EncodeInfo *encInfo);

/* Encode secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo);

/* Copy remaining image bytes from src to stego image file */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);

#endif
